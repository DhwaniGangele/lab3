(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_495e10._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_495e10._.js",
  "chunks": [
    "static/chunks/[root of the server]__7ba800._.css",
    "static/chunks/_95ad90._.js"
  ],
  "source": "dynamic"
});
