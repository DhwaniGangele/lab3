(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/a7abb_next_dist_compiled_react-dom_99acc9._.js",
    "static/chunks/a7abb_next_dist_compiled_c9fc5a._.js",
    "static/chunks/a7abb_next_dist_client_91ac0f._.js",
    "static/chunks/a7abb_next_dist_98d156._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d0afae._.js"
  ],
  "source": "entry"
});
