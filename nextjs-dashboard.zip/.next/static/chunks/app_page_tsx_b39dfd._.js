(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_b39dfd._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_b39dfd._.js",
  "chunks": [
    "static/chunks/_d30d83._.js"
  ],
  "source": "dynamic"
});
