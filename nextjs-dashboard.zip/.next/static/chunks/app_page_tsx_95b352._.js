(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_95b352._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_95b352._.js",
  "chunks": [
    "static/chunks/a7abb_next_dist_766dee._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js"
  ],
  "source": "dynamic"
});
