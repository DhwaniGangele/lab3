(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_9884dd._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_9884dd._.js",
  "chunks": [
    "static/chunks/app_ui_home_module_6dd21e.css",
    "static/chunks/a7abb_next_dist_2bdb56._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js"
  ],
  "source": "dynamic"
});
